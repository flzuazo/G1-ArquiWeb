package com.upc.g1tf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G1TfApplication {

    public static void main(String[] args) {
        SpringApplication.run(G1TfApplication.class, args);
    }

}
