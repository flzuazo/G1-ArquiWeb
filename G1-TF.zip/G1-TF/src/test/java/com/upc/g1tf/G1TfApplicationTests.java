package com.upc.g1tf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G1TfApplicationTests {

    @Test
    void contextLoads() {
    }

}
