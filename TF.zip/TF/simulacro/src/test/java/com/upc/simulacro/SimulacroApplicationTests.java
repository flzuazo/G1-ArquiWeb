package com.upc.simulacro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimulacroApplicationTests {

    @Test
    void contextLoads() {
    }

}
