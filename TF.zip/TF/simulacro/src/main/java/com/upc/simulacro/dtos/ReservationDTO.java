package com.upc.simulacro.dtos;

import com.upc.simulacro.entities.TouristPackage;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ReservationDTO {
    private Long id;
    private String ReservationCode;
    private LocalDate date;
    private int numberOfPeople;
    private Long touristPackageId;
}
