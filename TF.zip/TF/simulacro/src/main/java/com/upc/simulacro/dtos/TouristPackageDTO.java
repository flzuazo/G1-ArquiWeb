package com.upc.simulacro.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TouristPackageDTO {
    private Long id;
    private String name;
    private String description;
    private double price;
    private String mainDestination;
}
