package com.upc.tf.entidades;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Consulta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idConsulta;

    @OneToOne
    @JoinColumn(name = "idCita")
    private Cita cita;

    @ManyToOne
    @JoinColumn(name = "idPaciente")
    private Paciente paciente;

    @ManyToOne
    @JoinColumn(name = "idProfesional")
    private ProfesionalSalud profesional;

    private LocalDate fechaConsulta;
    private String diagnostico;
    private String tratamiento;

    @OneToMany(mappedBy = "consulta")
    private java.util.List<Diagnostico> diagnosticos;

    @OneToMany(mappedBy = "consulta")
    private java.util.List<Receta> recetas;
}
