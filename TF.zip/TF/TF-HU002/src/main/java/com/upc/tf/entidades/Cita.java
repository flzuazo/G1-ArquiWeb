package com.upc.tf.entidades;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Cita {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCita;

    @ManyToOne
    @JoinColumn(name = "idPaciente")
    private Paciente paciente;

    @ManyToOne
    @JoinColumn(name = "idProfesional")
    private ProfesionalSalud profesional;

    @ManyToOne
    @JoinColumn(name = "idCentro")
    private CentroMedico centroMedico;

    private LocalDate fechaCita;
    private LocalTime horaCita;

    private String estado;
    private String tipoCita;
    private String motivo;
}
